# server-info
This is a fivem server resource to do /discord and get the info for Texas State Roleplay's server
 
 # How to install/use this resource
 1. Click clone or download
 2. Drag and drop the folder that says server-info
 3. open the server.cfg and put start/ensure server-info
 4. Restart your server (or the resource) and type /discord
 
 # Should note that these ^ instructions are just for the client.lua. The client-looped.lua should be used if you want the server to send a chat message automatically. Be sure to change the client-looped.lua to client.lua or it will not work. 
 
 # how to change the color
 1. Find the line that says {255,0,0},
 2. Change the numbers inside the curly bracketts to fit your needs. It's rgb so google RGB and put the numbers inside the curly bracketts above to fit your needs
 
 # how to change what the command outputs (says in server)
 1. Find where it says msg("Discord: https://discord.gg/FfCeyKS")
    msg("Website: https://johnsonchristian10.wixsite.com/mysite/")
 2. Delete Everything inside the quotation marks and put whatever you want inside of there


IMPORTANT: This resource does NOT work, currently, with any other chat resource besides the base fivem chat resource. 
