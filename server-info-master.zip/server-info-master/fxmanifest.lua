fx_version 'cerulean'
games {'gta5'}

author 'Dasdawg428'
description 'Discord command for Texas State Roleplay'
version '1.0.0'

-- What to run
client_scripts {
    'client.lua'
}
